create view view_classAdviser_banji as select banid = banji.bid,bName=bName,banzhuid=classAdviser.tID,teachid = banji.tID from banji,classAdviser where banji.bID=1
go

