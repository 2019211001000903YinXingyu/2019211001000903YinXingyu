create view view_sName_bName_sintegrals as select stuid=students.sid,"stuname"=sName,'banji'=bName,jifen=sintegrals from students,banji,integrals where students.sid = integrals.sid and students.bID = banji.bID
go

