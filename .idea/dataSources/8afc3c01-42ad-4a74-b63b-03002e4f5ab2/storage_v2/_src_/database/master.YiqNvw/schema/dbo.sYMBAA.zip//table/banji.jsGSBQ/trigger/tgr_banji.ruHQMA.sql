create trigger tgr_banji on banji for insert
as
declare @banjiid int;
	select @banjiid=bid from inserted;
	insert into classAdviser values(@banjiid,null);

select * from banji
select * from classAdviser
go

