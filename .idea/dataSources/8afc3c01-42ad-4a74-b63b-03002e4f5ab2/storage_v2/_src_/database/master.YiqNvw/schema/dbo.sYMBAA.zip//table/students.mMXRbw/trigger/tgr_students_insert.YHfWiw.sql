create trigger tgr_students_insert on students for insert
as
declare @uname varchar(11),@pid int;
	select @uname=sid,@pid=5 from inserted;
	insert into users values(@uname,default,@pid);
	insert into integrals values(@uname,default);
go

