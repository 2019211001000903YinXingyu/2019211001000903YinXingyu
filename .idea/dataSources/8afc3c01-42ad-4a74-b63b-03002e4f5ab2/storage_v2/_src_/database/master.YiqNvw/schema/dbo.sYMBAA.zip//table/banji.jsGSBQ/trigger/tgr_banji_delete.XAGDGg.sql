create trigger tgr_banji_delete on banji instead of delete
as
declare @id int;
  select @id = bid from deleted;
  print @id;
  delete from classAdviser where banjiid = @id;
  delete from banji where bid = @id;
go

