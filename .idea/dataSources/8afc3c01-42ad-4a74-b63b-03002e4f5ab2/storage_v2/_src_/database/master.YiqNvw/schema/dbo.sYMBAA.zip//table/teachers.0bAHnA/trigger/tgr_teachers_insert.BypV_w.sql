create trigger tgr_teachers_insert on teachers for insert
as
declare @uname varchar(11),@pid int;
	select @uname=tid,@pid=pid from inserted;
	insert into users values(@uname,default,@pid);
go

