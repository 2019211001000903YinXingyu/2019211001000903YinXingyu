create trigger tgr_teachers_delete on teachers for delete
as
declare @uname varchar(11);
	select @uname=tid from deleted;
	delete from  users where uname = @uname;
go

