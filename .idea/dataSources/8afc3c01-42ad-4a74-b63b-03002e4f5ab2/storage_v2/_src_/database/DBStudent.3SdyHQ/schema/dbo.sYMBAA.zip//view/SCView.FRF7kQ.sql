create view SCView(学生学号,学生姓名,课程编号,课程名称,课程成绩)
as
select SC.StuNo,StuName,SC.CNo,CName,Grade from SC,Student,Course
where Student.StuNo=SC.StuNo and
	SC.CNo=Course.CNo
with check option
go

