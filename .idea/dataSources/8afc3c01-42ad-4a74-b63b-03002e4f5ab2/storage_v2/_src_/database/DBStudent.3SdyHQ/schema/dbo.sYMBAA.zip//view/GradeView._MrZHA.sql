create view GradeView(CNo,CName,HScore,LScore,AScore,FailRate)
as
select distinct SC.CNo,CName,Max(Grade),Min(Grade),Avg(Grade),CAST(SUM(case when Grade>='60'then 0 else 1 end) AS float)/count(SC.StuNo)
from SC,Course
where SC.CNo=Course.CNo
group by SC.CNo,Cname
with check option
go

