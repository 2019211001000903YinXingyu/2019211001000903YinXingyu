create view TeachView(职工编号,职工姓名,课程编号,课程名称)
as
select Teach.TNo,TName,Teach.CNo,CName from Teach,Teacher,Course
where Teach.TNo=Teacher.TNo and
	Teach.CNo=Course.CNo
with check option
go

