create view view4(读者姓名,读者编号,读者电话,书号,书名,借书日期,应还日期)
as
select reader.Rname,reader.Rno,reader.Rtel,book.Bname,book.Bno,rb.BorrowTime,dateadd(day,30,rb.BorrowTime) as 应还日期
from reader,book,rb
where reader.Rno=rb.Rno and
		book.Bno=rb.Bno and
		rb.ReturnTime is null
go

grant select on view4 to YinXingyu1
go

