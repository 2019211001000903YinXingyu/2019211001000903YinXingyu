create view view1
as
select bname,bno,bprice,bnum
from book
go

