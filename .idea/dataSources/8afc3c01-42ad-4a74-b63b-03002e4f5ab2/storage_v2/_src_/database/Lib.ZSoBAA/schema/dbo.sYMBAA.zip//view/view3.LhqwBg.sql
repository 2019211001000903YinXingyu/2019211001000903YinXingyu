create view view3(读者编号,读者电话号码,读者单位)
as
select Rno,Rtel,Rwork from reader
where Rwork='厨师'
go

grant select on view3 to YinXingyu1
go

