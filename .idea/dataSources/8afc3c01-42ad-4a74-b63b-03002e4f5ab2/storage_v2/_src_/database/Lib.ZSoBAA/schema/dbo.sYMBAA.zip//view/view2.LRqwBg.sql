create view view2(读者姓名,读者编号,读者电话号码,读者单位,书名,书号,借书日期,还书日期,应还日期,超期天数)
as
select reader.Rname,reader.Rno,reader.Rtel,reader.Rwork,book.Bname,book.Bno,rb.BorrowTime,rb.ReturnTime,dateadd(day,30,rb.BorrowTime) as 应还日期, DATEDIFF(DAY,BorrowTime,ReturnTime)-30 as 超期天数
from reader,book,rb
where reader.Rno=rb.Rno and
		book.Bno=rb.Bno and
		DATEDIFF(DAY,BorrowTime,ReturnTime)>30
go

